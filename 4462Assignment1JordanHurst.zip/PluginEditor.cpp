/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
ArpeggiatorEditor::ArpeggiatorEditor (Arpeggiator& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (400, 210);
    
	speedLabel.setText("Speed:", NotificationType::dontSendNotification);
	speedLabel.setJustificationType(juce::Justification::centredRight);
	speedLabel.attachToComponent(&speedSlider, true);
	addAndMakeVisible(speedLabel);

    speedSlider.setSliderStyle (juce::Slider::SliderStyle::LinearHorizontal);
    speedSlider.setRange (0.0, 1.0, 0.05);
    speedSlider.setTextBoxStyle (juce::Slider::TextEntryBoxPosition::NoTextBox, true, 90, 20);
    speedSlider.setPopupDisplayEnabled (true, true, this);
    speedSlider.setValue(0.5);
    addAndMakeVisible (&speedSlider);
	speedSlider.onValueChange = [this] {updateSpeed(); };

	durationLabel.setText("1st note Duration:", NotificationType::dontSendNotification);
	durationLabel.setJustificationType(juce::Justification::centredRight);
	durationLabel.attachToComponent(&durationSlider, true);
	addAndMakeVisible(durationLabel);

	durationSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
	durationSlider.setRange(0.25, 4.0, 0.25);
	durationSlider.setTextBoxStyle(juce::Slider::TextEntryBoxPosition::NoTextBox, true, 90, 20);
	durationSlider.setPopupDisplayEnabled(true, true, this);
	durationSlider.setValue(1.0);
	addAndMakeVisible(&durationSlider);
	durationSlider.onValueChange = [this] {updateDuration(); };

	ascendingToggle.setToggleState(true, NotificationType::dontSendNotification);
	addAndMakeVisible(ascendingToggle);
	ascendingToggle.onClick = [this] {updateAscending(); };

	sequenceLabel.setText("Sequence:", NotificationType::dontSendNotification);
	addAndMakeVisible(sequenceLabel);

	linearToggle.setToggleState(true, NotificationType::dontSendNotification);
	addAndMakeVisible(linearToggle);
	linearToggle.onClick = [this] {updateSequence(); };
	linearToggle.setRadioGroupId(1);

	shuffleToggle.setToggleState(false, NotificationType::dontSendNotification);
	addAndMakeVisible(shuffleToggle);
	shuffleToggle.onClick = [this] {updateSequence(); };
	shuffleToggle.setRadioGroupId(1);

	repeatToggle.setToggleState(false, NotificationType::dontSendNotification);
	addAndMakeVisible(repeatToggle);
	repeatToggle.onClick = [this] {updateSequence(); };
	repeatToggle.setRadioGroupId(1);

	addAndMakeVisible(octaveCombo);
	octaveCombo.addItem("1 Octave", 1);
	octaveCombo.addItem("2 Octaves", 2);
	octaveCombo.addItem("3 Octaves", 3);
	octaveCombo.onChange = [this] {updateOctaves(); };
	octaveCombo.setSelectedId(1);
}

ArpeggiatorEditor::~ArpeggiatorEditor()
{
}

//==============================================================================
void ArpeggiatorEditor::paint (juce::Graphics& g)
{
   // fill the whole window white
	g.fillAll(juce::Colours::darkslateblue);
    //g.fillAll (juce::Colour::Colour(143, 55, 163));

	g.setColour(juce::Colours::black);
	g.fillRoundedRectangle(199, 80, 2, 120, 1);
}

void ArpeggiatorEditor::resized()
{
    speedSlider.setBounds (130, 10, getWidth() - 130, 20);
	durationSlider.setBounds(130, 40, getWidth() - 130, 20);

	ascendingToggle.setBounds(210, 80, 180, 20);
	octaveCombo.setBounds(210, 110, 180, 20);

	sequenceLabel.setBounds(10, 80, 180, 20);
	linearToggle.setBounds(10, 110, 180, 20);
	shuffleToggle.setBounds(10, 140, 180, 20);
	repeatToggle.setBounds(10, 170, 180, 20);
}

void ArpeggiatorEditor::updateSpeed()
{
	audioProcessor.speed = speedSlider.getValue();
}

void ArpeggiatorEditor::updateDuration()
{
	audioProcessor.duration = durationSlider.getValue();
}

void ArpeggiatorEditor::updateAscending()
{
	audioProcessor.ascending = ascendingToggle.getToggleState();
}

void ArpeggiatorEditor::updateSequence()
{
	audioProcessor.shuffle = shuffleToggle.getToggleState();
	audioProcessor.repeat = repeatToggle.getToggleState();
}

void ArpeggiatorEditor::updateOctaves()
{
	audioProcessor.octaves = octaveCombo.getSelectedId();
}
