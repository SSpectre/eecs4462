/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class ArpeggiatorEditor  : public juce::AudioProcessorEditor
{
public:
    ArpeggiatorEditor (Arpeggiator&);
    ~ArpeggiatorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

private:
	void updateSpeed();
	void updateDuration();
	void updateAscending();
	void updateSequence();
	void updateOctaves();
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    Arpeggiator& audioProcessor;

	juce::Label speedLabel{ "Speed" };
    juce::Slider speedSlider;
	juce::Label durationLabel{ "First note duration:" };
	juce::Slider durationSlider;
	juce::ToggleButton ascendingToggle{ "Ascending" };
	juce::Label sequenceLabel{ "Sequence" };
	juce::ToggleButton linearToggle{ "Linear" };
	juce::ToggleButton shuffleToggle{ "Shuffle notes" };
	juce::ToggleButton repeatToggle{ "Repeat 1st note" };
	juce::ComboBox octaveCombo;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ArpeggiatorEditor)
};
